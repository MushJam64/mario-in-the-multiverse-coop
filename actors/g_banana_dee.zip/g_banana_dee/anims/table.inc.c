const struct Animation *const g_banana_dee_anims[] = {
	&g_banana_dee_anim_idle,
	NULL,
};
