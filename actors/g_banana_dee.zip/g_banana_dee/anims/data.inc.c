#include "anim_idle.inc.c"
