extern const struct Animation *const g_banana_dee_anims[];
